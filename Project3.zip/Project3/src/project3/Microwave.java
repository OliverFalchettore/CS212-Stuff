/*
 * Oliver Falchettore
 * 11/25/2024
 * Lab 111B 8:10am - 9:00am
 */
package project3;

/**
 * The Microwave class extends the Appliance class to include
 * additional attributes specific to a microwave, such as wattage.
 */
public class Microwave extends Appliance {

    private int watts;

    /**
     * Constructor to initialize a Microwave object.
     * 
     * @param serial the serial number of the microwave
     * @param p the price of the microwave
     * @param w the wattage of the microwave
     */
    public Microwave(String serial, int p, int w) {
        super(serial, p);
        watts = w;
    }


    /**
     * Returns a string representation of the microwave.
     * 
     * @return a string containing the serial number, price, and wattage
     */
    public String toString() {
        return getSerialNum() + ", " + "$" + getPrice() + ".00" + ", " + watts + "w";
    }

}
