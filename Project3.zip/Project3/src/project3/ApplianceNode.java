/*
 * Oliver Falchettore
 * 11/25/2024
 * Lab 111B 8:10am - 9:00am
 */

package project3;

/**
 * The ApplianceNode class represents a node in a linked list, 
 * containing data of type Appliance and a reference to the next node in the list.
 */
public class ApplianceNode {

    // The appliance data held by this node
    public Appliance data;

    // Reference to the next node in the list
    public ApplianceNode next;

    /**
     * Default constructor initializes the node with null data and next reference.
     */
    public ApplianceNode() {
        this.data = null;
        this.next = null;
    }

    /**
     * Constructor to initialize the node with given appliance data.
     * 
     * @param d the Appliance object to be stored in this node
     */
    public ApplianceNode(Appliance d) {
        data = d;
        next = null;
    }
}// class ApplianceNode
