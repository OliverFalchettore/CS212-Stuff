/*
 * Oliver Falchettore
 * 11/25/2024
 * Lab 111B 8:10am - 9:00am
 */

package project3;

/**
 * The SortedApplianceList class extends the ApplianceList class to ensure that
 * appliances are added in a sorted order based on their serial numbers.
 */
public class SortedApplianceList extends ApplianceList {

    /**
     * Constructor to initialize an empty SortedApplianceList.
     */
    public SortedApplianceList() {
        super();
    }

    /**
     * Adds a new Appliance to the list while keeping the list sorted by serial number.
     * 
     * @param d the Appliance to be added
     */
    public void add(Appliance d) {
        ApplianceNode newNode = new ApplianceNode(d);

        // If the list is empty, add the first node
        if (first.data == null) {
            first = newNode;
            last = newNode;
        } else if (newNode.data.getSerialNum().compareTo(first.data.getSerialNum()) < 0) {
            newNode.next = first;
            first = newNode;
        } else {
            ApplianceNode current = first;

            while (current.next != null && newNode.data.getSerialNum().compareTo(current.next.data.getSerialNum()) > 0) {
                current = current.next;
            }

            newNode.next = current.next;
            current.next = newNode;

            // If new node is added at the end, update last pointer
            if (newNode.next == null) {
                last = newNode;
            }
        }

        length++;
    }
}
