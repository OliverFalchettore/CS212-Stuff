/*
 * Oliver Falchettore
 * 11/25/2024
 * Lab 111B 8:10am - 9:00am
 */

package project3;

/**
 * Custom exception class for handling illegal appliance
 * operation. This exception is thrown when an invalid appliance
 * related operation is performed
 * 
 */

@SuppressWarnings("serial")
public class IllegalApplianceException extends IllegalArgumentException {
	
	/**
	 * Constructs an IllegalApplianceException with the specified detail
	 * message 
	 * 
	 * @param message
	 */
	public IllegalApplianceException(String message) {
		super(message);
	}

}
