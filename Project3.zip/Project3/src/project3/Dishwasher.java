/*
 * Oliver Falchettore
 * 11/25/2024
 * Lab 111B 8:10am - 9:00am
 */

package project3;

/**
 * The Dishwasher class extends the Appliance class to include 
 * additional attributes specific to a dishwasher, such as whether it is undercounter.
 */
public class Dishwasher extends Appliance {

    // Attribute representing whether the dishwasher is undercounter.
    private boolean undercounter;

    /**
     * Constructor to initialize a Dishwasher object.
     * 
     * @param serial the serial number of the dishwasher
     * @param p the price of the dishwasher
     * @param uc a boolean indicating if the dishwasher is undercounter ('Y' for yes, anything else for no)
     */
    public Dishwasher(String serial, int p, boolean uc) {
    	
        super(serial, p);
        
        undercounter = uc;
    }


    /**
     * Returns a string representation of the dishwasher.
     * 
     * @return a string containing the serial number, price, and whether it is undercounter
     */
    public String toString() {
        if (!undercounter) {
            return getSerialNum() + ", " + "$" + getPrice() + ".00" + ", " + "Not Undercounter";
        }
        return getSerialNum() + ", " + "$" + getPrice() + ".00" + ", " + "Undercounter";
    }
}

