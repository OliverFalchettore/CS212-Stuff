/*
 * Oliver Falchettore
 * 11/25/2024
 * Lab 111B 8:10am - 9:00am
 */

package project3;

import javax.swing.*;
import java.awt.event.*;
import java.io.File;
import java.util.StringTokenizer;


/**
 * FileMenuHandler class handles actions performed on the file menu.
 * It listens for user interactions with the menu and executes the
 * corresponding actions.
 */
public class FileMenuHandler implements ActionListener {
    // Static fields to manage the appliance list and related data
    static SortedApplianceList AppList = new SortedApplianceList();
    static int size = 0;
    static StringTokenizer myTokens;
    static String curr_serialnum;
    static int curr_price;
    static Appliance curr_n;
	

    JFrame jframe;
    
    /**
     * Construct a FileMenuHandler with the specified JFrame
     * 
     * @param jf the JFrame to be associated with this handler
     */
    public FileMenuHandler (JFrame jf) {
    	jframe = jf;
    }
    
    
    /**
     * Handles the action performed event. Executes the corresponding action
     * based on the menu item selected
     * 
     * @param event the ActionEvent triggered by the user action
     */
    public void actionPerformed(ActionEvent event) {
    	String menuName = event.getActionCommand();
    	if (menuName.equals("Open"))
    		OpenFile();
    	else if (menuName.equals("Quit"))
    		System.exit(0);
    } //actionPerformed
   
   
    
    /**
     * Opens a file. This method should be implented to define the behavior 
     * when the "Open" menu item is selected
     */
    private void OpenFile() {
    	JFileChooser chooser = new JFileChooser();
    	@SuppressWarnings("unused")
    	int status = chooser.showOpenDialog(null);
    	readSource(chooser.getSelectedFile());
    }

   /**
    * Stores appliance data from a given file into the SortedApplianceList and then updating the list
    * 
    * @param chosenFile the name of the file containing appliance data
    */
   
    private void readSource(File chosenFile) {
    	String chosenFileName = chosenFile.getAbsolutePath();
    	TextFileInput in = new TextFileInput(chosenFileName);
    	String curr = in.readLine();
	
    	while (curr != null) {
    		size++;
    		curr = in.readLine();
    	}
	
    	// Send the cursor back to the beginning of the file
    	in = new TextFileInput(chosenFileName);
	
    	for (int i = 0; i < size; i++) {
    		String currApp = in.readLine();
    		myTokens = new StringTokenizer(currApp, ",");
    		try {
    			curr_serialnum = myTokens.nextToken();
    			curr_price = Integer.parseInt(myTokens.nextToken());    			
    			
    			if (currApp.charAt(0) == 'R') {
    				int cubicfeet = Integer.parseInt(myTokens.nextToken());
    				Refrigerator newFridge = new Refrigerator(curr_serialnum, curr_price, cubicfeet);
    				curr_n = newFridge;
    				AppList.add(curr_n);
	
	               
    			} else if (currApp.charAt(0) == 'D') {         
    				boolean undercounter = myTokens.nextToken().charAt(0) == 'Y' ? true : false;	               
    				Dishwasher newDishwasher = new Dishwasher(curr_serialnum, curr_price, undercounter);
    				curr_n = newDishwasher;
    				AppList.add(curr_n);
	
	
    			} else if (currApp.charAt(0) == 'M'){
    				int watts = Integer.parseInt(myTokens.nextToken());   
    				Microwave newMicrowave = new Microwave(curr_serialnum, curr_price, watts);
    				curr_n = newMicrowave;       
    				AppList.add(curr_n);
    			//If it doesn't start with either R, D, or M
    			}else {
    				throw new IllegalApplianceException("Serial number: " + curr_serialnum + " -  is not valid");
    			}
    		} catch(IllegalApplianceException e) {
    			System.out.println(e.getMessage());
    		}
	
	       
    	}
    	
    	
    	//Puts the linked list content into the GUI Text Areas
    	ApplianceGUI.updateList(AppList);
       
    }
    

   
}