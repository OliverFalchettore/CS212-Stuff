/*
 * Oliver Falchettore
 * 11/25/2024
 * Lab 111B 8:10am - 9:00am
 */

package project3;

/**
 * The ApplianceList class represents an abstract linked list of appliances.
 * It provides basic functionality to manage a list of appliances.
 */
public abstract class ApplianceList {

    // The first node in the list
    protected ApplianceNode first;

    // The last node in the list
    protected ApplianceNode last;

    // The number of nodes in the list
    protected int length;

    /**
     * Constructor to initialize an empty ApplianceList.
     * Creates a dummy node to start the list.
     */
    public ApplianceList() {
        ApplianceNode ln = new ApplianceNode();
        first = ln;
        last = ln;
        length = 0;
    }

    /**
     * Appends a new Appliance to the end of the list.
     * 
     * @param d the Appliance to be added
     */
    public void append(Appliance d) {
        ApplianceNode n = new ApplianceNode(d);
        last.next = n;
        last = n;
        length++;
    }
}
