/*
 * Oliver Falchettore
 * 11/25/2024
 * Lab 111B 8:10am - 9:00am
 */

package project3;

/**
 * The main method where the application starts. 
 * It initializes the ApplianceGUI
 */
public class Project3 {
    public static void main(String[] args) {
        @SuppressWarnings("unused")
		ApplianceGUI appGUI = new ApplianceGUI();
    }
}