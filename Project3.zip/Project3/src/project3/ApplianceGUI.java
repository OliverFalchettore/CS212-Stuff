/*
 * Oliver Falchettore
 * 11/25/2024
 * Lab 111B 8:10am - 9:00am
 */

package project3;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.TextArea;
import javax.swing.*;


/**
 * The ApplianceGUI class extends JFrame to create a GUI for displaying appliance serial numbers.
 */
@SuppressWarnings("serial")
public class ApplianceGUI extends JFrame {

    // Text areas for displaying different types of appliances
    private static TextArea Refrigerator_list;
    private static TextArea Dishwasher_list;
    private static TextArea Microwave_list;

    /**
     * Constructor to initialize the ApplianceGUI.
     */
    public ApplianceGUI() {
        setSize(800, 600);
        setLocation(100, 100);
        setTitle("Appliance Serial Numbers");
        createFileMenu();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Initialize text areas
        Refrigerator_list = new TextArea();
        Dishwasher_list = new TextArea();
        Microwave_list = new TextArea();

        // Set text areas to non-editable
        Refrigerator_list.setEditable(false);
        Dishwasher_list.setEditable(false);
        Microwave_list.setEditable(false);

        // Set layout manager 
        Container myContentPane = getContentPane();
        getContentPane().setLayout(new GridLayout(1, 3));

        // Add text areas to content pane
        myContentPane.add(Refrigerator_list);
        myContentPane.add(Dishwasher_list);
        myContentPane.add(Microwave_list);
        
        setVisible(true);
    }

    /**
     * Updates the lists in the GUI with the data from the given SortedApplianceList.
     * 
     * @param appList the SortedApplianceList containing appliances to be displayed
     */
    public static void updateList(SortedApplianceList appList) {
        ApplianceNode p = appList.first;

        while (p != null) {
            if (p.data instanceof Refrigerator) {
                Refrigerator_list.append(p.data.toString() + "\n");
            } else if (p.data instanceof Dishwasher) {
                Dishwasher_list.append(p.data.toString() + "\n");
            } else if (p.data instanceof Microwave) {
                Microwave_list.append(p.data.toString() + "\n");
            }

            p = p.next;
        }
    }
    
    private void createFileMenu() {
    	JMenuBar menuBar = new JMenuBar();
    	JMenu fileMenu = new JMenu("File");
    	JMenuItem item;
    	FileMenuHandler fmh = new FileMenuHandler(this);
    	item = new JMenuItem("Open");
    	item.addActionListener(fmh);
    	fileMenu.add(item);
    	fileMenu.addSeparator();
    	item = new JMenuItem("Quit");
    	item.addActionListener(fmh);
    	fileMenu.add(item);
    	menuBar.add(fileMenu);
    	setJMenuBar(menuBar);
    }
}
