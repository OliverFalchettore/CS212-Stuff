/*
 * Oliver Falchettore 
 * 12/10/2024
 * Lab 111B 8:10am - 9:00am
 */

package project4;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The Appliance class represents a general appliance with a serial number and a price.
 * It provides methods to get and set these attributes and to compare appliances based on their serial numbers.
 */
public abstract class Appliance {

    private String SerialNum;
    
    private int price;

    /**
     * Constructor to initialize an Appliance object.
     * 
     * @param s the serial number of the appliance
     * @param p the price of the appliance
     */
    public Appliance(String s, int p) throws IllegalApplianceException{
    	
    	if(!isValid(s)) {
    		throw new IllegalApplianceException("Serial number: " + s + " -  is not valid");
    	}
    	
        SerialNum = s;
        price = p;
    }

    /**
     * Gets the serial number of the appliance.
     * 
     * @return the serial number as a string
     */
    public String getSerialNum() {
        return SerialNum;
    }

    /**
     * Sets the serial number of the appliance.
     * 
     * @param s the new serial number as a string
     */
    public void setSerialNum(String s) {
        SerialNum = s;
    }

    /**
     * Gets the price of the appliance.
     * 
     * @return the price as an integer
     */
    public int getPrice() {
        return price;
    }

    /**
     * Sets the price of the appliance.
     * 
     * @param p the new price as an integer
     */
    public void setPrice(int p) {
        price = p;
    }

    /**
     * Converts the Appliance object to a string representation.
     * 
     * @return the serial number of the appliance as a string
     */
    public String toString() {
        return SerialNum;
    }


    /**
     * Compares this Appliance to another Appliance lexicographically by serial number.
     * 
     * @param other the other Appliance to compare to
     * @return a negative integer if this Appliance's serial number is less than the other Appliance's serial number,
     *         0 if they are equal,
     *         or a positive integer if this Appliance's serial number is greater than the other Appliance's serial number
     */
    public int compareTo(Appliance other) {
        return this.SerialNum.compareTo(other.SerialNum);
    }
    
    /**
     * Validates a given serial number against a predefined pattern.
     * 
     * @param serial
     * @return
     */
    public boolean isValid(String serial) {
    	Pattern p;
    	Matcher m;
    	
    	p = Pattern.compile("^[RDM][A-Z0-9]{11}$"); 
    	
    	m = p.matcher(serial);
    	
    	
    	return m.matches();
    }
}
