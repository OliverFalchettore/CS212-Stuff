/*
 * Oliver Falchettore 
 * 12/10/2024
 * Lab 111B 8:10am - 9:00am
 */

package project4;

/**
 * The IllegalApplianceException class extends IllegalArgumentException to handle
 * exceptions related to illegal appliances.
 * This exception is thrown when an appliance does not meet the required criteria.
 */
@SuppressWarnings("serial")
public class IllegalApplianceException extends IllegalArgumentException {
    
    /**
     * Constructs an IllegalApplianceException with the specified detail message.
     *
     * @param message the detail message
     */
    public IllegalApplianceException(String message) {
        super(message);
    }
}
