/*
 * Oliver Falchettore 
 * 12/10/2024
 * Lab 111B 8:10am - 9:00am
 */

package project4;

import java.util.Comparator;

/**
 * Compares two Appliance objects for order. Returns a negative integer, zero, 
 * or a positive integer if the first argument is less than, equal to, or greater than the second.
 * 
 * @param o1 the first Appliance to be compared.
 * @param o2 the second Appliance to be compared.
 * @return a negative integer, zero, or a positive integer if the first Appliance
 *         is less than, equal to, or greater than the second Appliance.
 */

public class ApplianceComparator implements Comparator<Appliance>{

	@Override
	public int compare(Appliance o1, Appliance o2) {
		// TODO Auto-generated method stub
		return o1.compareTo(o2);
	}

}
