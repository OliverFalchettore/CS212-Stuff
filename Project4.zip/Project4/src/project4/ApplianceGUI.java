/*
 * Oliver Falchettore 
 * 12/10/2024
 * Lab 111B 8:10am - 9:00am
 */

package project4;

import java.awt.TextArea;
import java.awt.GridLayout;
import java.awt.Container;
import javax.swing.*;

/**
 * The ApplianceGUI class extends JFrame and handles all the UI aspects of the program.
 */
@SuppressWarnings("serial")
public class ApplianceGUI extends JFrame {

    // Text areas for displaying different types of appliances
    private static TextArea Refrigerator_list;
    private static TextArea Dishwasher_list;
    private static TextArea Microwave_list;
    private JMenuBar menuBar = new JMenuBar();

    /**
     * Constructs an ApplianceGUI and initializes the UI components.
     */
    public ApplianceGUI() {
        setSize(800, 600);
        setLocation(100, 100);
        setTitle("Appliance Serial Numbers");
        createFileMenu();
        createSearchMenu();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Initialize text areas
        Refrigerator_list = new TextArea();
        Dishwasher_list = new TextArea();
        Microwave_list = new TextArea();

        // Set text areas to non-editable
        Refrigerator_list.setEditable(false);
        Dishwasher_list.setEditable(false);
        Microwave_list.setEditable(false);

        // Set layout manager
        Container myContentPane = getContentPane();
        myContentPane.setLayout(new GridLayout(1, 3));

        // Add text areas to content pane
        myContentPane.add(Refrigerator_list);
        myContentPane.add(Dishwasher_list);
        myContentPane.add(Microwave_list);

        setVisible(true);
    }

    /**
     * Appends text to the Refrigerator_list TextArea.
     *
     * @param text the text to be appended
     */
    public static void appendToRefridgeratorList(String text) {
        Refrigerator_list.append(text + "\n");
    }

    /**
     * Appends text to the Dishwasher_list TextArea.
     *
     * @param text the text to be appended
     */
    public static void appendToDishwasherList(String text) {
        Dishwasher_list.append(text + "\n");
    }

    /**
     * Appends text to the Microwave_list TextArea.
     *
     * @param text the text to be appended
     */
    public static void appendToMicrowaveList(String text) {
        Microwave_list.append(text + "\n");
    }

    /**
     * Creates the menu bar and functionality of file handling.
     */
    private void createFileMenu() {
        JMenu fileMenu = new JMenu("File");
        JMenuItem item;
        FileMenuHandler fmh = new FileMenuHandler(this);
        item = new JMenuItem("Open");
        item.addActionListener(fmh);
        fileMenu.add(item);
        fileMenu.addSeparator();
        item = new JMenuItem("Quit");
        item.addActionListener(fmh);
        fileMenu.add(item);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);
    }

    /**
     * Creates the menu bar and functionality for searching.
     */
    private void createSearchMenu() {
        JMenu searchMenu = new JMenu("Search");
        JMenuItem item;
        SearchMenuHandler smh = new SearchMenuHandler(this);
        item = new JMenuItem("Price Filter");
        item.addActionListener(smh);
        searchMenu.add(item);
        menuBar.add(searchMenu);
    }
}
