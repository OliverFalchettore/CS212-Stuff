/*
 * Oliver Falchettore 
 * 12/10/2024
 * Lab 111B 8:10am - 9:00am
 */

package project4;

import java.util.TreeMap;

/**
 * The Refrigerator class extends the Appliance class to include
 * additional attributes specific to a refrigerator, such as cubic feet.
 */

public class Refrigerator extends Appliance{
	/**
	 * Tree map to store refrigerator appliances
	 */
	public static TreeMap <Appliance, Integer> refrigerator_map = new TreeMap<>(new ApplianceComparator());
	
	private int cubic_feet;
	
	/**
	 * 
	 * Constructor to initialize a Refrigerator object
	 * 
	 * @param serial - the serial number of the refrigerator
	 * @param p - the price of the refrigerator
	 * @param cf - the cubic feet capacity of the refrigerator
	 */
	public Refrigerator(String serial, int p, int cf) {
		super(serial, p);
		cubic_feet = cf;
	}
	
	
	/**
	 * Returns a string representation of the refrigerator
	 * 
	 * @return a string containing the serial number, price, and cubic feet
	 */
	public String toString() {
		return getSerialNum() + ", " + "$" + getPrice() + ".00" + ", " + cubic_feet + " cubic ft";
	}

}