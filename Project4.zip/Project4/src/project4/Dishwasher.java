/*
 * Oliver Falchettore 
 * 12/10/2024
 * Lab 111B 8:10am - 9:00am
 */

package project4;

import java.util.TreeMap;

/**
 * The Dishwasher class extends the Appliance class to include 
 * additional attributes specific to a dishwasher, such as whether it is undercounter.
 */
public class Dishwasher extends Appliance {
	/**
	 * Tree map to store dishwasher appliances
	 */
	public static TreeMap <Appliance, Integer> dishwasher_map = new TreeMap<>(new ApplianceComparator());
	
	
    // Attribute representing whether the dishwasher is undercounter.
    private boolean undercounter;

    /**
     * Constructor to initialize a Dishwasher object.
     * 
     * @param serial the serial number of the dishwasher
     * @param p the price of the dishwasher
     * @param uc a boolean indicating if the dishwasher is undercounter ('Y' for yes, anything else for no)
     */
    public Dishwasher(String serial, int p, boolean uc) {
    	
        super(serial, p);
        
        undercounter = uc;
    }


    /**
     * Returns a string representation of the dishwasher.
     * 
     * @return a string containing the serial number, price, and whether it is undercounter
     */
    public String toString() {
        if (!undercounter) {
            return getSerialNum() + ", " + "$" + getPrice() + ".00" + ", " + "Not Undercounter";
        }
        return getSerialNum() + ", " + "$" + getPrice() + ".00" + ", " + "Undercounter";
    }
}

