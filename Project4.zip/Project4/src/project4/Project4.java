/*
 * Oliver Falchettore 
 * 12/10/2024
 * Lab 111B 8:10am - 9:00am
 */

package project4;



/**
 * Main program file
 */
public class Project4 {
	public static void main(String[] args) {
		@SuppressWarnings("unused")
		ApplianceGUI appGUI = new ApplianceGUI();
	}
}
