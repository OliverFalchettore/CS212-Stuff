/*
 * Oliver Falchettore 
 * 12/10/2024
 * Lab 111B 8:10am - 9:00am
 */

package project4;

import java.awt.event.*;
import java.io.File;
import java.util.Map;
import java.util.StringTokenizer;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

/**
 * FileMenuHandler class handles actions performed on the file menu.
 * It listens for user interactions with the menu and executes the
 * corresponding actions.
 */
public class FileMenuHandler implements ActionListener{

    static StringTokenizer myTokens;
    static String curr_serialnum;
    static int curr_price;
    static Appliance curr_n;
    static int size = 0;

    @SuppressWarnings("unused")
	private JFrame jframe;

    /**
     * Constructs a FileMenuHandler with the specified JFrame.
     *
     * @param jf the JFrame to be associated with this handler
     */
    public FileMenuHandler(JFrame jf) {
        jframe = jf;
    }

    /**
     * Invoked when an action occurs. This method determines the action command
     * and performs the corresponding operation.
     *
     * @param event the event to be processed
     */
    @Override
    public void actionPerformed(ActionEvent event) {
        String menuName = event.getActionCommand();
        if (menuName.equals("Open")) {
            OpenFile();
        } else if (menuName.equals("Quit")) {
            System.exit(0);
        }
    }

    /**
     * Opens a file. This method defines the behavior when the "Open" menu item is selected.
     */
    private void OpenFile() {
        JFileChooser chooser = new JFileChooser();
        @SuppressWarnings("unused")
        int status = chooser.showOpenDialog(null);
        readSource(chooser.getSelectedFile());
    }

    /**
     * Reads the contents of the chosen file and processes the appliances.
     *
     * @param chosenFile the file to be read
     */
    private void readSource(File chosenFile) {
        String chosenFileName = chosenFile.getAbsolutePath();
        TextFileInput in = new TextFileInput(chosenFileName);
        String curr = in.readLine();

        while (curr != null) {
            size++;
            curr = in.readLine();
        }

        // Send the cursor back to the beginning of the file
        in = new TextFileInput(chosenFileName);
        for (int i = 0; i < size; i++) {
            String currApp = in.readLine();
            myTokens = new StringTokenizer(currApp, ",");
            try {
                curr_serialnum = myTokens.nextToken();
                curr_price = Integer.parseInt(myTokens.nextToken());

                if (currApp.charAt(0) == 'R') {
                    int cubicfeet = Integer.parseInt(myTokens.nextToken());
                    Refrigerator newFridge = new Refrigerator(curr_serialnum, curr_price, cubicfeet);
                    Refrigerator.refrigerator_map.put(newFridge, curr_price);

                } else if (currApp.charAt(0) == 'D') {
                    boolean undercounter = myTokens.nextToken().charAt(0) == 'Y' ? true : false;
                    Dishwasher newDishwasher = new Dishwasher(curr_serialnum, curr_price, undercounter);
                    Dishwasher.dishwasher_map.put(newDishwasher, curr_price);

                } else if (currApp.charAt(0) == 'M') {
                    int watts = Integer.parseInt(myTokens.nextToken());
                    Microwave newMicrowave = new Microwave(curr_serialnum, curr_price, watts);
                    Microwave.microwave_map.put(newMicrowave, curr_price);

                // If it doesn't start with either R, D, or M
                } else {
                    throw new IllegalApplianceException("Serial number: " + curr_serialnum + " - is not valid");
                }
            } catch (IllegalApplianceException e) {
                System.out.println(e.getMessage());
            }
        }

        updateTextList();
    }

    /**
     * Updates the text areas in the ApplianceGUI with the contents of the appliance maps.
     */
    private void updateTextList() {
        for (Map.Entry<Appliance, Integer> r : Refrigerator.refrigerator_map.entrySet()) {
            ApplianceGUI.appendToRefridgeratorList(r.getKey().toString());
        }

        for (Map.Entry<Appliance, Integer> d : Dishwasher.dishwasher_map.entrySet()) {
            ApplianceGUI.appendToDishwasherList(d.getKey().toString());
        }

        for (Map.Entry<Appliance, Integer> m : Microwave.microwave_map.entrySet()) {
            ApplianceGUI.appendToMicrowaveList(m.getKey().toString());
        }
    }
}
