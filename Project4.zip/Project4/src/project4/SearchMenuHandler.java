/*
 * Oliver Falchettore 
 * 12/10/2024
 * Lab 111B 8:10am - 9:00am
 */

package project4;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map.Entry;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * The SearchMenuHandler class implements ActionListener to handle menu actions.
 * It provides methods to perform search operations based on user input.
 */
public class SearchMenuHandler implements ActionListener {
    @SuppressWarnings("unused")
	private JFrame jframe;

    /**
     * Constructs a SearchMenuHandler with the specified JFrame.
     *
     * @param jf the JFrame to be associated with this handler
     */
    public SearchMenuHandler(JFrame jf) {
        jframe = jf;
    }

    /**
     * Invoked when an action occurs. This method determines the action command and
     * performs the corresponding operation.
     *
     * @param e the event to be processed
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        String searchName = e.getActionCommand();
        if (searchName.equals("Price Filter") && Refrigerator.refrigerator_map.isEmpty()
                                             && Dishwasher.dishwasher_map.isEmpty()
                                             && Microwave.microwave_map.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No file input");

        } else if (searchName.equals("Price Filter")) {
            SearchBox();
        }
    }

    /**
     * Displays a search box to the user for input. If the input is invalid, it prompts the user to try again.
     */
    private void SearchBox() {
        String input = JOptionPane.showInputDialog(null, "Please enter R, M, or D followed by a comma and a price");

        while (!isValidSearch(input)) {
            JOptionPane.showMessageDialog(null, "Invalid input - Try Again");
            input = JOptionPane.showInputDialog(null, "Please enter R, M, or D followed by a comma and a price \n example: R, 2000");
        }

        printPriceMatch(input);
    }

    /**
     * Validates the user input against a predefined pattern.
     *
     * @param s the input string to be validated
     * @return true if the input is valid, false otherwise
     */
    private boolean isValidSearch(String s) {
        Pattern p;
        Matcher m;

        p = Pattern.compile("^[RDM]{1},[ ]?\\d+$");

        m = p.matcher(s);

        return m.matches();
    }

    /**
     * Prints appliances that match the search criteria based on the input string.
     *
     * @param s the input string containing the appliance type and price
     */
    private void printPriceMatch(String s) {
    	//used to split the string
        StringTokenizer myToken = new StringTokenizer(s, ",");
        char appliancetype = s.charAt(0);
        myToken.nextToken();
        int price = Integer.parseInt(myToken.nextToken().trim());

        if (appliancetype == 'R') {
            for (Entry<Appliance, Integer> refrigerators : Refrigerator.refrigerator_map.entrySet()) {
                if (refrigerators.getValue() <= price) {
                    System.out.println(refrigerators.getKey().toString());
                }
            }

        } else if (appliancetype == 'D') {
            for (Entry<Appliance, Integer> dishwashers : Dishwasher.dishwasher_map.entrySet()) {
                if (dishwashers.getValue() <= price) {
                    System.out.println(dishwashers.getKey().toString());
                }
            }

        } else if (appliancetype == 'M') {
            for (Entry<Appliance, Integer> microwaves : Microwave.microwave_map.entrySet()) {
                if (microwaves.getValue() <= price) {
                    System.out.println(microwaves.getKey().toString());
                }
            }
        }
    }
}
